/*Ler um conjunto de numeros reais, armazenando-o em vetor e calcular o quadrado das
componentes deste vetor, armazenando o resultado em outro vetor. Os conjuntos teˆ m
10 elementos cada. Imprimir todos os conjuntos.*/

#include <iostream>
using namespace std;
int main(){

  int vetor[10];
  int vetor2[10];

  for(int i = 0; i < 10; i++){
    cout << "Digite o numero da posição " << i << endl;
    cin >> vetor[i];
    vetor2[i] = vetor[i] * vetor[i];
  }

  cout << endl;

  for(int i = 0; i < 10; i ++){
    cout << "Os valores da posição " << i << " do primeiro conjunto é: " << vetor[i] << endl;
  }

  cout << endl << endl;
  

  for(int i = 0; i < 10; i++){
    cout << "Os valores ao quadrado desse conjunto na posição " << i << " é " << vetor2[i] << endl;
  }
   
  return 0;
}