#include <iostream>
using namespace std;
int main(){

  int vetor[10];
  int maior;

    cout << "Digite os 10 valores do vetor: " << endl;
    cin >> vetor[0];
    maior = vetor[0];

  for(int i = 1; i < 10; i++){
      cin >> vetor[i];
      if (vetor[i] > maior)
          maior = vetor[i];
  }

  cout << endl;

  cout << "O maior numero é: " << maior << endl;

  for(int i = 0; i < 10; i++){
    if(vetor[i] == maior)  
      cout << "A posição (de 0 a 9) do maior numero é: " << i << endl;
  }

  return 0;
}