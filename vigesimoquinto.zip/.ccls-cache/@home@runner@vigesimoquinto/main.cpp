#include <iostream>
using namespace std;

bool naoMultiploDeSeteOuTerminaComSete(int num) {
    // Verifica se não é múltiplo de 7 ou termina com o algarismo 7
    return (num % 7 != 0) || (num % 10 == 7);
}

int main() {
    const int TAMANHO_VETOR = 100;
    int vetor[TAMANHO_VETOR];
    int numero = 1; // Começa a busca a partir do número 1
    int count = 0;  // Contador de elementos inseridos no vetor

    while (count < TAMANHO_VETOR) {
        if (naoMultiploDeSeteOuTerminaComSete(numero)) {
            vetor[count] = numero;
            count++;
        }
        numero++;
    }

    // Exibindo os elementos do vetor
    cout << "Os primeiros 100 naturais que não são múltiplos de 7 ou terminam com 7:" << endl;
    for (int i = 0; i < TAMANHO_VETOR; ++i) {
        cout << vetor[i];
        if (i < TAMANHO_VETOR - 1) {
            cout << ", ";
        } else {
            cout << ".";
        }
    }
    cout << endl;

    return 0;
}
