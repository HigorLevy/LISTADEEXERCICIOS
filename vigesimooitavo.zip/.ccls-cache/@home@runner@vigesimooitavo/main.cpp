#include <iostream>
#include <vector>
using namespace std;

int main() {
    const int tamanho = 10;
    vector<int> v(tamanho);
    vector<int> v1, v2;

    // Lendo os números e armazenando no vetor v
    cout << "Digite " << tamanho << " numeros inteiros:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o numero " << i + 1 << ": ";
        cin >> v[i];
    }

    // Separando os valores ímpares para o vetor v1 e pares para o vetor v2
    for (int i = 0; i < tamanho; ++i) {
        if (v[i] % 2 != 0) {
            v1.push_back(v[i]); // Adiciona número ímpar ao vetor v1
        } else {
            v2.push_back(v[i]); // Adiciona número par ao vetor v2
        }
    }

    // Imprimindo os elementos UTILIZADOS de v1
    cout << "\nElementos UTILIZADOS de v1 (valores impares):" << endl;
    for (size_t i = 0; i < v1.size(); ++i) {
        cout << v1[i] << " ";
    }
    cout << endl;

    // Imprimindo os elementos UTILIZADOS de v2
    cout << "\nElementos UTILIZADOS de v2 (valores pares):" << endl;
    for (size_t i = 0; i < v2.size(); ++i) {
        cout << v2[i] << " ";
    }
    cout << endl;

    return 0;
}
