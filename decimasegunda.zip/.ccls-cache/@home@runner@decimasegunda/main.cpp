#include <iostream>
using namespace std;

int main() {
    float vetor[5];
    float maior, menor, media = 0;

    cout << "Digite 5 valores: \n";
    for(int i = 0; i < 5; i++) {
        cin >> vetor[i];
        media += vetor[i];
        if (i == 0) {
            maior = menor = vetor[0];
        } else {
            if (vetor[i] > maior)
                maior = vetor[i];
            if (vetor[i] < menor)
                menor = vetor[i];
        }
    }

    media /= 5;

    cout << endl;

    cout << "Os valores inseridos são: " << endl;
    for(int i = 0; i < 5; i++) {
        cout << vetor[i] << " ";
    }

    cout << endl;

    cout << "\nO maior valor é: " << maior << endl << endl;
    cout << "Já o menor valor é: " << menor << endl << endl;
    cout << "E a media é igual a: " << media << endl << endl;
    cout << endl;

    return 0;
}