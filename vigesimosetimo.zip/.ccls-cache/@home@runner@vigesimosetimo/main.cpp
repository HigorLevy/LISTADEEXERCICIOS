#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// Função para verificar se um número é primo
bool ehPrimo(int num) {
    if (num <= 1) return false; // Números menores ou iguais a 1 não são primos
    if (num == 2) return true;  // O número 2 é primo
    if (num % 2 == 0) return false; // Números pares maiores que 2 não são primos

    // Verificando divisibilidade a partir de 3 até a raiz quadrada de num
    int limite = sqrt(num);
    for (int i = 3; i <= limite; i += 2) {
        if (num % i == 0) {
            return false; // Encontrou um divisor, não é primo
        }
    }
    return true; // Se não encontrou divisores, é primo
}

int main() {
    const int tamanho = 10;
    vector<int> numeros(tamanho);

    // Lendo os números e armazenando no vetor
    cout << "Digite " << tamanho << " numeros inteiros:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o numero " << i + 1 << ": ";
        cin >> numeros[i];
    }

    // Exibindo os números primos e suas posições
    cout << "Numeros primos encontrados e suas posicoes no vetor:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        if (ehPrimo(numeros[i])) {
            cout << "Numero primo: " << numeros[i] << " - Posicao: " << i << endl;
        }
    }

    return 0;
}
