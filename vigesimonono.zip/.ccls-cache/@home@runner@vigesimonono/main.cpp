#include <iostream>
using namespace std;

int main() {
    const int tamanho = 6;
    int numeros[tamanho];
    int pares[tamanho], impares[tamanho];
    int somaPares = 0;
    int qtdImpares = 0;

    // Leitura dos 6 números inteiros
    cout << "Digite 6 numeros inteiros:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o numero " << i + 1 << ": ";
        cin >> numeros[i];

        // Verifica se o número é par ou ímpar
        if (numeros[i] % 2 == 0) {
            pares[i] = numeros[i];
            somaPares += numeros[i];
        } else {
            impares[qtdImpares] = numeros[i];
            qtdImpares++;
        }
    }

    // Mostrando os números pares digitados
    cout << "\nNumeros pares digitados:" << endl;
    bool haPares = false;
    for (int i = 0; i < tamanho; ++i) {
        if (numeros[i] % 2 == 0) {
            cout << pares[i] << " ";
            haPares = true;
        }
    }
    if (!haPares) {
        cout << "Nenhum numero par foi digitado.";
    }
    cout << endl;

    // Mostrando a soma dos números pares digitados
    cout << "Soma dos numeros pares digitados: " << somaPares << endl;

    // Mostrando os números ímpares digitados
    cout << "\nNumeros impares digitados:" << endl;
    bool haImpares = false;
    for (int i = 0; i < qtdImpares; ++i) {
        cout << impares[i] << " ";
        haImpares = true;
    }
    if (!haImpares) {
        cout << "Nenhum numero impar foi digitado.";
    }
    cout << endl;

    // Mostrando a quantidade de números ímpares digitados
    cout << "Quantidade de numeros impares digitados: " << qtdImpares << endl;

    return 0;
}
