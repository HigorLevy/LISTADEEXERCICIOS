#include <iostream>
#include <vector>
using namespace std;
int main(){

  vector<int> vetor(10);

  cout << "Digite 10 valores: " << endl;
  for(int i = 0; i < 10; i ++){
    cin >> vetor[i];

    if(vetor[i] < 0){
      vetor[i] = 0;
    }
  }

  return 0;
}