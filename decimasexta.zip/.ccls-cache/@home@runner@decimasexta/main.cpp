#include <iostream>
#include <vector>
using namespace std;

void ordemDireta(const vector<float>& vetor){
  cout << endl;
  cout << "Exibindo numeros em ordem direta: " << endl;
  for(int i = 0; i < vetor.size(); i ++){
    cout << vetor[i] << " ";
    
  }}

void ordemInversa(const vector<float>& vetor){
  cout << endl;
  cout << "Exibindo os numeros em ordem inversa: " << endl;
  for(int i = vetor.size() - 1; i >= 0; i--){
    cout << vetor[i] << " ";
  }
}

int main(){

  int codigo;

  vector<float> vetor(5);

  cout << "->Digite 5 valores: " << endl;
  for(int i = 0; i < 5; i++){
    cin >> vetor[i];
  }

  while(true){
    cout << "\n====MENU====\n";
    cout << "0 - Sair\n";
    cout << "1 - Exibir em ordem direta\n";
    cout << "2 - Exibir em ordem inversa\n";
    cout << "\n->Digite um codigo de acordo com a ação acima desejada; \n";
    cin >> codigo;

  switch (codigo){
    
    case 0:
    cout << endl;
    cout << "->Saindo..." << endl;
    return 0;

    case 1:
    ordemDireta(vetor);
    cout << endl;
    break;

    case 2:
    cout << endl;
    ordemInversa(vetor);
    break;
    
    default:
    cout << "->Codigo invalido. Tente novamente.\n";
  }}

  return 0;
}