#include <iostream>
using namespace std;
int main(){

  float vetor[15];
  float soma = 0;

  cout << "Digite as notas dos alunos: " << endl;
  for(int i = 0; i < 15; i++){
  cin >> vetor[i];
  soma += vetor[i];
  }

  float mediageral = soma /15;

  cout << mediageral << endl;
  
  return 0;
}