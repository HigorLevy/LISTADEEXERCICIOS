/*Fac ̧ a um programa que leia um vetor de 8 posic ̧ o ̃ es e, em seguida, leia tambe ́ m dois va-
lores X e Y quaisquer correspondentes a duas posic ̧ o ̃ es no vetor. Ao final seu programa
devera ́ escrever a soma dos valores encontrados nas respectivas posic ̧ o ̃ es X e Y .*/
#include <iostream>
using namespace std;
int main(){

  int vetor[8];
  int x, y;

  cout << "Digite 8 valores: " << endl;
  for(int i = 0; i < 8; i++){
    cin >> vetor[i];
  }

  cout << "Digite o valor de X (entre 0 e 7): \n";
  cin >> x;
  cout << "Digite o valor de Y (entre 0 e 7): \n";
  cin >> y;

  if(x >= 0 && x < 8 && y >= 0 && y < 8){
    int soma = vetor[x] + vetor[y];
    cout << "O valor da soma dos valores nas posições " << x << " e " << y << " é: " << soma << endl;
   }
  else{
    cout << "Posições inválidas\n";
  }
  
  return 0;
}