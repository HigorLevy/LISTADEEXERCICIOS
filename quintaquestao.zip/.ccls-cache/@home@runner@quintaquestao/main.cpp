#include <iostream>
using namespace std;
int main(){

  int vetor[10];
  int x = 0;

  for(int i = 0; i < 10; i++){
    
    cout << "Digite o número da posição " << i << ": ";
    cin >> vetor[i];
  }

  cout << endl;

  cout << "Os numeros pares são: \n";
  for(int i = 0; i < 10; i++){
    if(vetor[i] % 2 == 0){
      cout << vetor[i] << " ";
      x++;
    }}

  cout << endl;
  

  cout << "O vetor possui " << x << " números pares!\n";
  
  return 0;
}