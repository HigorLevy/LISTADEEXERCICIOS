#include <iostream>
#include <string>
using namespace std;
int main(){

  int soma = 0;
  
  int vetor[6] = {1, 0, 5, -2, -5, 7};

  soma = vetor[0] + vetor[1] + vetor[5];

  cout << "A soma dos elementos " << vetor[0] << ", " << vetor[1] << ", " << vetor[5] << ", " << " é igual a " << soma << endl;

  cout << endl;
  
  vetor[4] = 100;

  for(int i = 0; i < 6; i++){
    cout << "o valor do elemento " << i << " é igual a " << vetor[i] << endl;
  }
  
  return 0;
}