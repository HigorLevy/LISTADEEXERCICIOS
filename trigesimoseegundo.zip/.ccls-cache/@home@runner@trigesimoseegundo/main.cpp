#include <iostream>
#include <vector>
#include <algorithm> // Para usar std::sort e std::set_intersection
using namespace std;

const int tamanho = 5;

// Função para imprimir um vetor
void imprimirVetor(const vector<int>& vetor) {
    cout << "[ ";
    for (int i = 0; i < vetor.size(); ++i) {
        cout << vetor[i] << " ";
    }
    cout << "]" << endl;
}

// Função para calcular a soma entre dois vetores
vector<int> somaEntreVetores(const vector<int>& x, const vector<int>& y) {
    vector<int> resultado(tamanho);
    for (int i = 0; i < tamanho; ++i) {
        resultado[i] = x[i] + y[i];
    }
    return resultado;
}

// Função para calcular o produto entre dois vetores
vector<int> produtoEntreVetores(const vector<int>& x, const vector<int>& y) {
    vector<int> resultado(tamanho);
    for (int i = 0; i < tamanho; ++i) {
        resultado[i] = x[i] * y[i];
    }
    return resultado;
}

// Função para calcular a diferença entre dois vetores
vector<int> diferencaEntreVetores(const vector<int>& x, const vector<int>& y) {
    vector<int> diferenca;
    for (int i = 0; i < tamanho; ++i) {
        if (find(y.begin(), y.end(), x[i]) == y.end()) {
            diferenca.push_back(x[i]);
        }
    }
    return diferenca;
}

// Função para calcular a interseção entre dois vetores
vector<int> intersecaoEntreVetores(const vector<int>& x, const vector<int>& y) {
    vector<int> intersecao;
    for (int i = 0; i < tamanho; ++i) {
        if (find(y.begin(), y.end(), x[i]) != y.end()) {
            intersecao.push_back(x[i]);
        }
    }
    return intersecao;
}

// Função para calcular a união entre dois vetores
vector<int> uniaoEntreVetores(const vector<int>& x, const vector<int>& y) {
    vector<int> uniao = x;
    for (int i = 0; i < tamanho; ++i) {
        if (find(x.begin(), x.end(), y[i]) == x.end()) {
            uniao.push_back(y[i]);
        }
    }
    return uniao;
}

int main() {
    vector<int> x(tamanho), y(tamanho);

    // Leitura dos vetores x e y
    cout << "Digite os elementos do vetor x (5 elementos diferentes):" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> x[i];
    }

    cout << "\nDigite os elementos do vetor y (5 elementos diferentes):" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> y[i];
    }

    // Calculando e mostrando os resultados
    cout << "\nVetor x: ";
    imprimirVetor(x);
    cout << "Vetor y: ";
    imprimirVetor(y);

    // Soma entre x e y
    cout << "\nSoma entre x e y: ";
    vector<int> soma = somaEntreVetores(x, y);
    imprimirVetor(soma);

    // Produto entre x e y
    cout << "Produto entre x e y: ";
    vector<int> produto = produtoEntreVetores(x, y);
    imprimirVetor(produto);

    // Diferença entre x e y
    cout << "Diferença entre x e y (elementos de x que não estão em y): ";
    vector<int> diferenca = diferencaEntreVetores(x, y);
    imprimirVetor(diferenca);

    // Interseção entre x e y
    cout << "Interseção entre x e y: ";
    vector<int> intersecao = intersecaoEntreVetores(x, y);
    imprimirVetor(intersecao);

    // União entre x e y
    cout << "União entre x e y (sem elementos repetidos): ";
    vector<int> uniao = uniaoEntreVetores(x, y);
    imprimirVetor(uniao);

    return 0;
}
