#include <iostream>
#include <algorithm> // Para utilizar a função std::sort e std::unique
using namespace std;

const int tamanho = 10;

// Função para imprimir um vetor
void imprimirVetor(int vetor[], int tamanho) {
    cout << "[ ";
    for (int i = 0; i < tamanho; ++i) {
        cout << vetor[i] << " ";
    }
    cout << "]" << endl;
}

// Função para criar a união de dois vetores
void criarUniao(int vetor1[], int vetor2[], int uniao[], int &tamanhoUniao) {
    // Concatenar os elementos dos dois vetores em uniao[]
    for (int i = 0; i < tamanho; ++i) {
        uniao[tamanhoUniao++] = vetor1[i];
        uniao[tamanhoUniao++] = vetor2[i];
    }

    // Ordenar o vetor de união para facilitar a remoção de duplicatas
    sort(uniao, uniao + tamanhoUniao);

    // Remover elementos duplicados usando a função std::unique
    auto it = unique(uniao, uniao + tamanhoUniao);

    // Atualizar o tamanho do vetor de união após a remoção de duplicatas
    tamanhoUniao = distance(uniao, it);
}

int main() {
    int vetor1[tamanho], vetor2[tamanho];
    int uniao[2 * tamanho]; // Vetor para armazenar a união
    int tamanhoUniao = 0;   // Variável para controlar o tamanho do vetor de união

    // Leitura do primeiro vetor
    cout << "Digite os elementos do primeiro vetor:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> vetor1[i];
    }

    // Leitura do segundo vetor
    cout << "\nDigite os elementos do segundo vetor:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> vetor2[i];
    }

    // Criar a união dos dois vetores
    criarUniao(vetor1, vetor2, uniao, tamanhoUniao);

    // Imprimir o vetor de união
    cout << "\nElementos na união dos dois vetores:" << endl;
    imprimirVetor(uniao, tamanhoUniao);

    return 0;
}
