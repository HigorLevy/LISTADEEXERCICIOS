#include <iostream>
using namespace std;
int main(){

  int vetor[10];
  int maior, menor;

    cout << "Digite os 10 valores do vetor: " << endl;
    cin >> vetor[0];
    maior = menor = vetor[0];
  
  for(int i = 1; i < 10; i++){
      cin >> vetor[i];
      if (vetor[i] > maior)
          maior = vetor[i];
      if (vetor[i] < menor)
          menor = vetor[i];
  }

  cout << endl;

  cout << "O maior numero é: " << maior << endl;
  cout << "O menor numero é: " << menor << endl;
  
  return 0;
}