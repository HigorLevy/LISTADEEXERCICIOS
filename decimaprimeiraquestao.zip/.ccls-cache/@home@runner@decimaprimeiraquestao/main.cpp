#include <iostream>
using namespace std;
int main(){

  float vetor[10];
  int x = 0;
  float somaPositivo = 0;

  cout << "Digite 10 numeros reais: " << endl;
  for(int i = 0; i < 10; i++){
    cin >> vetor[i];
  }

  for(int i = 0; i < 10; i++){
    if(vetor[i] < 0){
      x++;
    }
    else{
      somaPositivo += vetor[i];
      }
    }

  cout << endl;

  cout << "A quantidade de valores negativos é: " << x << endl;
  cout << "A soma dos valores positivos é: " << somaPositivo << endl;
  
  return 0;
}