#include <iostream>
using namespace std;

int main() {
    float vetor[10];
    cout << "Digite 10 valores: " << endl;
    for (int i = 0; i < 10; i++) {
        cin >> vetor[i];
    }

    cout << "Valores repetidos: ";
    for (int i = 0; i < 10; i++) {
        for (int j = i + 1; j < 10; j++) {
            if (vetor[i] == vetor[j]) {
                cout << vetor[i] << " ";
                break; 
            }
        }
    }

    cout << endl;
    return 0;
}