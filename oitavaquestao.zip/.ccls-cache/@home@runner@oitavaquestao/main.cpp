#include <iostream>
using namespace std;
int main(){

  int vetor[6];

  cout << "Digite 6 valores: " << endl;
  for(int i=0; i<6; i++){
    cin >> vetor[i];}

  cout << vetor[5] << ", " << vetor[4] << ", " << vetor[3] << ", "      << vetor[2] << ", " << vetor[1] << ", " << vetor[0] << endl;

  return 0;
}