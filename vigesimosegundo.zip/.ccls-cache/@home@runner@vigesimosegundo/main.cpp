#include <iostream>
using namespace std;

const int TAMANHO = 10;

void lerVetor(int vetor[], int tamanho, string nome) {
    cout << "Digite os elementos do vetor " << nome << ":" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << nome << "[" << i << "]: ";
        cin >> vetor[i];
    }
    cout << endl;
}

void calcularVetorResultado(int A[], int B[], int C[]) {
    for (int i = 0; i < TAMANHO; ++i) {
        if (i % 2 == 0) {
            // Posições pares: valores do vetor A
            C[i] = A[i];
        } else {
            // Posições ímpares: valores do vetor B
            C[i] = B[i];
        }
    }
}

void mostrarVetor(int vetor[], int tamanho, string nome) {
    cout << "Vetor " << nome << ":" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << nome << "[" << i << "]: " << vetor[i] << endl;
    }
    cout << endl;
}

int main() {
    int A[TAMANHO], B[TAMANHO], C[TAMANHO];

    // Leitura dos vetores A e B
    lerVetor(A, TAMANHO, "A");
    lerVetor(B, TAMANHO, "B");

    // Cálculo do vetor C
    calcularVetorResultado(A, B, C);

    // Exibição dos vetores A, B e C
    mostrarVetor(A, TAMANHO, "A");
    mostrarVetor(B, TAMANHO, "B");
    mostrarVetor(C, TAMANHO, "C");

    return 0;
}