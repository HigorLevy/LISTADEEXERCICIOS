#include <iostream>
using namespace std;

int main() {
    const int tamanho = 10;
    int vetor[tamanho];

    cout << "Digite 10 números inteiros:\n";
    for (int i = 0; i < tamanho; ++i) {
        cout << "Número " << i + 1 << ": ";
        cin >> vetor[i];
    }

    int x;
    cout << "\nDigite um número para encontrar seus múltiplos no vetor: ";
    cin >> x;

    int contador = 0;
    cout << "Múltiplos de " << x << " no vetor:\n";
    for (int i = 0; i < tamanho; ++i) {
        if (vetor[i] % x == 0) {
            cout << vetor[i] << " ";
            contador++;
        }
    }

    if (contador == 0) {
        cout << "Nenhum múltiplo de " << x << " encontrado no vetor.\n";
    }

    return 0;
}