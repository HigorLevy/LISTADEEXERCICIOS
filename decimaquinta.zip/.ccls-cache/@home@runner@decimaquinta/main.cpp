#include <iostream>
#include <vector>
#include <set>
using namespace std;
int main(){

  vector<int> vetor(20);

  cout << "->Digite 20 valores inteiros: " << endl;
  for(int i = 0; i < 20; i++){
    cin >> vetor[i];
  }

  set<int> conjunto;
  
  for(int i = 0; i < 20; i++){
    conjunto.insert(vetor[i]);
  }

  cout << endl;
  
  cout << "->Os valores do vetor sem os numeros repetidos são: \n";
  for(auto it = conjunto.begin(); it != conjunto.end(); it++){
    cout << *it << " "; 
  }
  
  return 0;
}