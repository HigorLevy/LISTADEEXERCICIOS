#include <iostream>
#include <cmath>
using namespace std;

// Função para calcular o desvio padrão
double calcularDesvioPadrao(int vetor[], int n) {
    double media = 0.0, soma = 0.0;

    // Calculando a média
    for (int i = 0; i < n; ++i) {
        media += vetor[i];
    }
    media /= n;

    // Calculando a soma dos quadrados das diferenças
    for (int i = 0; i < n; ++i) {
        soma += pow(vetor[i] - media, 2);
    }

    // Calculando o desvio padrão
    double desvioPadrao = sqrt(soma / n);

    return desvioPadrao;
}

int main() {
    const int n = 10; // Tamanho do vetor
    int vetor[n];

    // Lendo os elementos do vetor
    cout << "Digite " << n << " numeros inteiros:" << endl;
    for (int i = 0; i < n; ++i) {
        cout << "Digite o numero " << i + 1 << ": ";
        cin >> vetor[i];
    }

    // Calculando o desvio padrão
    double desvio = calcularDesvioPadrao(vetor, n);

    // Exibindo o resultado
    cout << "O desvio padrao do vetor eh: " << desvio << endl;

    return 0;
}
