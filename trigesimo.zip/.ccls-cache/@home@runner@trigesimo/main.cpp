#include <iostream>
#include <algorithm> // Para utilizar a função std::sort e std::unique
using namespace std;

const int tamanho = 10;

// Função para imprimir um vetor
void imprimirVetor(int vetor[], int tamanho) {
    cout << "[ ";
    for (int i = 0; i < tamanho; ++i) {
        cout << vetor[i] << " ";
    }
    cout << "]" << endl;
}

// Função para encontrar a interseção entre dois vetores
void encontrarIntersecao(int vetor1[], int vetor2[], int intersecao[]) {
    int pos = 0;
    // Ordena os vetores para facilitar a busca da interseção
    sort(vetor1, vetor1 + tamanho);
    sort(vetor2, vetor2 + tamanho);

    // Encontra a interseção utilizando a função std::set_intersection
    auto it = set_intersection(vetor1, vetor1 + tamanho, vetor2, vetor2 + tamanho, intersecao);

    // Atualiza o tamanho do vetor de interseção
    tamanho = it - intersecao;
}

int main() {
    int vetor1[tamanho], vetor2[tamanho];
    int intersecao[tamanho]; // Vetor para armazenar a interseção

    // Leitura do primeiro vetor
    cout << "Digite os elementos do primeiro vetor:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> vetor1[i];
    }

    // Leitura do segundo vetor
    cout << "\nDigite os elementos do segundo vetor:" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> vetor2[i];
    }

    // Encontrar a interseção entre os vetores
    encontrarIntersecao(vetor1, vetor2, intersecao);

    // Remove elementos repetidos da interseção
    sort(intersecao, intersecao + tamanho);
    auto it = unique(intersecao, intersecao + tamanho);
    tamanho = it - intersecao;

    // Imprime o vetor de interseção
    cout << "\nElementos na intersecao dos dois vetores:" << endl;
    imprimirVetor(intersecao, tamanho);

    return 0;
}
