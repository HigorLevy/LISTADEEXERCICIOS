#include <iostream>
using namespace std;

const int TAMANHO = 10;

int main() {
    int A[TAMANHO], B[TAMANHO], C[TAMANHO];

    // Entrada dos valores para o vetor A
    cout << "Digite os elementos do vetor A (10 numeros inteiros):" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "A[" << i << "]: ";
        cin >> A[i];
    }

    // Entrada dos valores para o vetor B
    cout << "\nDigite os elementos do vetor B (10 numeros inteiros):" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "B[" << i << "]: ";
        cin >> B[i];
    }

    // Calculando o vetor C = A - B
    for (int i = 0; i < TAMANHO; ++i) {
        C[i] = A[i] - B[i];
    }

    // Exibindo os elementos do vetor C
    cout << "\nVetor C (A - B):" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "C[" << i << "]: " << C[i] << endl;
    }

    return 0;
}