#include <iostream>
using namespace std;

const int TAMANHO = 5;

void lerVetor(double vetor[], int tamanho, string nome) {
    cout << "Digite os elementos do vetor " << nome << ":" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << nome << "[" << i << "]: ";
        cin >> vetor[i];
    }
    cout << endl;
}

double calcularProdutoEscalar(double vetor1[], double vetor2[], int tamanho) {
    double produtoEscalar = 0.0;
    for (int i = 0; i < tamanho; ++i) {
        produtoEscalar += vetor1[i] * vetor2[i];
    }
    return produtoEscalar;
}

void mostrarVetor(double vetor[], int tamanho, string nome) {
    cout << "Vetor " << nome << ":" << endl;
    for (int i = 0; i < tamanho; ++i) {
        cout << nome << "[" << i << "]: " << vetor[i] << endl;
    }
    cout << endl;
}

int main() {
    double vetor1[TAMANHO], vetor2[TAMANHO];

    // Leitura dos vetores
    lerVetor(vetor1, TAMANHO, "Vetor 1");
    lerVetor(vetor2, TAMANHO, "Vetor 2");

    // Cálculo do produto escalar
    double produtoEscalar = calcularProdutoEscalar(vetor1, vetor2, TAMANHO);

    // Exibição dos vetores e do produto escalar
    mostrarVetor(vetor1, TAMANHO, "Vetor 1");
    mostrarVetor(vetor2, TAMANHO, "Vetor 2");
    cout << "Produto Escalar: " << produtoEscalar << endl;

    return 0;
}