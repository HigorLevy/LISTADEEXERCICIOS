#include <iostream>
using namespace std;

int main() {
    const int tamanho = 10;
    int vetor[tamanho];
    int vetorImpares[tamanho]; // Vetor para armazenar números ímpares
    int contadorImpares = 0;   // Contador para controlar o preenchimento do vetor de ímpares

    // Leitura e validação dos números no intervalo [0, 50]
    cout << "Digite 10 valores entre 0 e 50:\n";
    for (int i = 0; i < tamanho; i++) {
        cin >> vetor[i];
        // Validar se o número está dentro do intervalo [0, 50]
        while (vetor[i] < 0 || vetor[i] > 50) {
            cout << "Valor inválido! Digite novamente: ";
            cin >> vetor[i];
        }
    }

    // Preenchimento do vetor de números ímpares
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] % 2 != 0) { // Verifica se o número é ímpar
            vetorImpares[contadorImpares] = vetor[i];
            contadorImpares++;
        }
    }

    // Impressão dos vetores, 2 elementos por linha
    cout << "\nValores dos vetores (2 elementos por linha):\n";
    for (int i = 0; i < tamanho; i += 2) {
        // Primeira coluna
        if (i < tamanho) {
            cout << vetor[i] << " ";
        }
        if (i + 1 < tamanho) {
            cout << vetor[i + 1] << " ";
        }
        cout << "\t"; // Separador entre as colunas

        // Segunda coluna (vetor de ímpares)
        if (i < contadorImpares) {
            cout << vetorImpares[i];
        }
        if (i + 1 < contadorImpares) {
            cout << " " << vetorImpares[i + 1];
        }
        cout << endl;
    }

    return 0;
}