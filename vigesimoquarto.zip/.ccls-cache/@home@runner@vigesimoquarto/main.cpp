#include <iostream>
using namespace std;

const int NUM_ALUNOS = 10;

int main() {
    int numeroAluno;
    double altura;
    int alunoMaisBaixo, alunoMaisAlto;
    double alturaMaisBaixa = 9999.0;  // Inicializa com um valor muito alto
    double alturaMaisAlta = 0.0;      // Inicializa com zero

    for (int i = 0; i < NUM_ALUNOS; ++i) {
        cout << "Digite o número do aluno " << i+1 << ": ";
        cin >> numeroAluno;
        cout << "Digite a altura do aluno " << i+1 << " (em metros): ";
        cin >> altura;

        if (altura < alturaMaisBaixa) {
            alturaMaisBaixa = altura;
            alunoMaisBaixo = numeroAluno;
        }

        if (altura > alturaMaisAlta) {
            alturaMaisAlta = altura;
            alunoMaisAlto = numeroAluno;
        }
    }

    cout << "\nAluno mais baixo:" << endl;
    cout << "Número do aluno: " << alunoMaisBaixo << endl;
    cout << "Altura: " << alturaMaisBaixa << " metros" << endl;

    cout << "\nAluno mais alto:" << endl;
    cout << "Número do aluno: " << alunoMaisAlto << endl;
    cout << "Altura: " << alturaMaisAlta << " metros" << endl;

    return 0;
}