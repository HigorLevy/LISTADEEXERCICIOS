#include <iostream>
using namespace std;
int main(){

  int vetor[6];
  bool Pares = true;

  cout << "Digite 6 valores apenas PARES: " << endl;
  for(int i=0; i<6; i++){
    cin >> vetor[i];
  }

  cout << endl;
  
  for(int i = 1; i < 6; i++){
  if(vetor[i]%2!=0){
    Pares = false;
    break;
    }
  }

  if(Pares){
    cout << "Os valores em ordem inversa são: " <<vetor[5] << ", " << vetor[4] << ", " << vetor[3] << ", " << vetor[2] << ", " << vetor[1] << ", " << vetor[0] << endl;
  }
  else{
    cout << "Valores invalidos, digite apenas numeros pares" << endl;
  }
  
  return 0;
}